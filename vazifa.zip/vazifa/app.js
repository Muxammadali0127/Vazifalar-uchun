const express = require('express')
const io = require('./model/io')
const rw = new io( __dirname +'/databases/data.json')
const Todo = require('./model/todo')
console.log(io)

const app = express()
const todos = 
app.use(express.json())

app.post('/add' , async(req, res) =>{


  const {name, text, views} = req.body
  const todo = await rw.read()
  const check = todo.filter((el) =>el.name == name)
  

  if(check.length)
  return res.send({message : 'Other user has posted by like this name please take other name'})
  const id = (todo[todo.length - 1]?.id || 0) + 1
  const newtodo = new Todo(id,name,text,views)
  const newdata = todo.length?[...todo, newtodo]:[newtodo]
  rw.write(newdata)
  res.send({message: 'block has added succesfully'})
})
app.put('/rename/:id', async(req, res) =>{
    const id = req.params.id
    const {name, text, views} = req.body
    const newtodo = new Todo(id, name, text, views)
   const data =await rw.read()
   const newdata = data.filter((el) => el.id != id)
   const superdata = newdata.length?[...newdata,newtodo ]:[newtodo]
   rw.write(superdata)
})

app.put('/blogs', async(req, res) =>{
    const data =await rw.read()
    const {name} = req.body
    for (const iterator of data) {
        if(iterator.name == name)
        console.log(iterator.views+=1)
        
    }
    rw.write(data)
   
})





app.listen(4000, (err) =>{
    console.log("4000 port is litining")
})
