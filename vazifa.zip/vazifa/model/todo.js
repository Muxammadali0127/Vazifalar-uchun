class Todo{
    constructor(id, name, text, views){
        this.id = id,
        this.name = name,
        this.text = text,
        this.views = views
        this.creat_data = new Date()
    }
}

module.exports = Todo;